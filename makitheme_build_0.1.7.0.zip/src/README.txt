IF YOU'RE READING THIS, YOU ARE PLANNING ON FORKING OFF THIS RELEASE
----------

Though I've released this under a  The Artistic License 2.0 license, I won't stop you. You can go ahead and make a derivative of this theme, for as long as:

1.) You, under any circumstances, do not claim any art/character relating to Love Live! or Maki Nishikino as your own;
2.) You will attribute your work as a derivative of our work
3.) Any element of code will not be used for commercial purposes. Exceptions are: Screenshots of the theme being used by you, and for any element that cannot be identifiable or traced back to this release.

If you think you are okay with all of the above, then, goodluck!

If you got further questions, send it to hello@mediaindex.zendesk.com

OR follow me at twitter.com/DotCrosse
And better yet, Like us @ facebook! fb.me/sakuraindex

Cheers

Alex